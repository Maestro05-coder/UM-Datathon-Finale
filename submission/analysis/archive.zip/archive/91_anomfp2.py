"""Second pass: is the country skew a chain-length artefact, and what marks each typology's amount?"""
import duckdb

c = duckdb.connect()
c.execute("SET threads=8")
c.execute("SET memory_limit='12GB'")
P = "analysis/payments.parquet"

print("=== anomaly rate by visible participants ===")
print(c.execute(f"""
select PARTICIPANT_COUNT pc, count(*) n,
  count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'') a,
  round(100.0*count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'')/count(*),3) per100k_x100
from '{P}' where PARTICIPANT_COUNT<=8 group by 1 order by 1""").df().to_string(index=False))

print("\n=== beneficiary-country anomaly rate within pc=2 only ===")
print(c.execute(f"""
select substr(BENEFICIARY_BIC8,5,2) bc, count(*) n,
  count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'') a,
  round(1e5*count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'')/count(*),1) per100k
from '{P}' where PARTICIPANT_COUNT=2 group by 1 having count(*)>=1000
order by per100k desc limit 12""").df().to_string(index=False))

print("\n=== amount shape: trailing zeros in USD_AMOUNT (scaled to integer cents) ===")
print(c.execute(f"""
with b as (
  select coalesce(ANOMALY_TYPE,'none') a, USD_AMOUNT amt,
         case when amt>0 then round(log10(amt)) end lg
  from '{P}' where USD_AMOUNT>0
)
select a, count(*) n,
  round(avg(case when amt = round(amt/1000)*1000 and amt>=1000 then 1 else 0 end),3) mult_1k,
  round(avg(case when amt = round(amt/100)*100 and amt>=100 then 1 else 0 end),3) mult_100,
  round(avg(case when amt < 500 then 1 else 0 end),3) under_500,
  round(median(amt),0) med
from b group by 1 order by n desc""").df().to_string(index=False))

print("\n=== FAT_FINGER: amount relative to same corridor median ===")
print(c.execute(f"""
with base as (
  select ANOMALY_TYPE a, ORDERING_BIC8||BENEFICIARY_BIC8 k, USD_AMOUNT amt
  from '{P}'
), med as (
  select k, median(amt) m from base group by 1
)
select a, count(*) n, round(median(amt/nullif(m,0)),1) ratio_med,
       round(quantile_cont(amt/nullif(m,0),0.1),1) p10,
       round(quantile_cont(amt/nullif(m,0),0.9),1) p90
from base join med using (k) where m>0 group by 1 order by n desc""").df().to_string(index=False))
