import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
# for EUR, per date, find the top amount in 4 bands
q=f"""
with x as (
 select date_trunc('day', to_timestamp(EPOCH_SECONDS)) d, USD_AMOUNT a, count(*) n
 from '{p}' where CURRENCY_CODE='EUR' and USD_AMOUNT between 90 and 130000 group by 1,2
), y as (
 select d,a,n, case when a between 95 and 130 then 100 when a between 950 and 1300 then 1000
   when a between 9500 and 13000 then 10000 else 100000 end band,
   row_number() over (partition by d, case when a between 95 and 130 then 100 when a between 950 and 1300 then 1000
   when a between 9500 and 13000 then 10000 else 100000 end order by n desc) rk
 from x)
select d, band, a, n from y where rk=1 order by band, d
"""
df=c.execute(q).df()
piv=df.pivot(index='d',columns='band',values='a')
piv['r100']=piv[100]/100; piv['r1000']=piv[1000]/1000; piv['r10000']=piv[10000]/10000; piv['r100000']=piv[100000]/100000
print(piv.head(40).to_string())
print(piv[['r100','r1000','r10000','r100000']].describe())
print('corr', piv[['r100','r1000','r10000']].corr())
