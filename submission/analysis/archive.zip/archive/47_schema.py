import duckdb
c=duckdb.connect()
p='analysis/payments.parquet'
print(c.execute(f"describe select * from '{p}'").df().to_string(index=False))
print()
print(c.execute(f"select * from '{p}' limit 2").df().T.to_string())
