import polars as pl
df=pl.read_parquet('analysis/payments.parquet', n_rows=200000)
import re
def oc(t):
    m=re.findall(r'<country_code:([A-Z]{2})>',t or '')
    return m[-1] if m else ''
rows=df.head(12)
for r in rows.iter_rows(named=True):
    print('----')
    for k in ['ORDERING_BIC8','BENEFICIARY_BIC8','ORDERING_TYPE','BENEFICIARY_TYPE','CURRENCY_CODE','USD_AMOUNT']:
        print(k,'=',r[k])
    print('OD:',repr(r['ORDERING_DETAILS']))
    print('OT:',repr(r['ORDERING_TOKENS']))
    print('BD:',repr(r['BENEFICIARY_DETAILS']))
    print('BT:',repr(r['BENEFICIARY_TOKENS']))
