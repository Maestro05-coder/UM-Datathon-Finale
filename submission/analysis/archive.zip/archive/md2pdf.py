"""Markdown -> PDF (A4) with reportlab, styled to match the dashboard pack.

Usage:  python analysis/md2pdf.py <input.md> <output.pdf> ["Title"]
"""
import os
import re
import sys

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, KeepTogether, ListFlowable,
                                ListItem, PageTemplate, Paragraph, Spacer, Table,
                                TableStyle)

NAVY = colors.HexColor("#0B3D6B")
TEAL = colors.HexColor("#1F6F8B")
GOLD = colors.HexColor("#C9962B")
GREY = colors.HexColor("#595959")
LIGHT = colors.HexColor("#F2F5F9")
RULE = colors.HexColor("#D9DEE5")

FONTS = {
    "Calibri": r"C:\Windows\Fonts\calibri.ttf",
    "Calibri-Bold": r"C:\Windows\Fonts\calibrib.ttf",
    "Calibri-Italic": r"C:\Windows\Fonts\calibrii.ttf",
    "Calibri-BoldItalic": r"C:\Windows\Fonts\calibriz.ttf",
    "Consolas": r"C:\Windows\Fonts\consola.ttf",
}
for name, path in FONTS.items():
    if os.path.exists(path):
        pdfmetrics.registerFont(TTFont(name, path))
pdfmetrics.registerFontFamily("Calibri", normal="Calibri", bold="Calibri-Bold",
                              italic="Calibri-Italic", boldItalic="Calibri-BoldItalic")

BODY = ParagraphStyle("body", fontName="Calibri", fontSize=9.9, leading=14.4,
                      textColor=colors.HexColor("#1F2937"), spaceAfter=6, alignment=TA_LEFT)
H1 = ParagraphStyle("h1", fontName="Calibri-Bold", fontSize=15.5, leading=19, textColor=NAVY,
                    spaceBefore=14, spaceAfter=7, keepWithNext=1)
H2 = ParagraphStyle("h2", fontName="Calibri-Bold", fontSize=11.6, leading=15, textColor=TEAL,
                    spaceBefore=11, spaceAfter=4, keepWithNext=1)
BULLET = ParagraphStyle("bullet", parent=BODY, leftIndent=13, bulletIndent=3, spaceAfter=2.5)
TCELL = ParagraphStyle("cell", fontName="Calibri", fontSize=8.5, leading=11,
                       textColor=colors.HexColor("#1F2937"))
THEAD = ParagraphStyle("thead", fontName="Calibri-Bold", fontSize=8.5, leading=11,
                       textColor=colors.white)
META = ParagraphStyle("meta", fontName="Calibri", fontSize=9.2, leading=13, textColor=GREY)


def inline(t):
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"`([^`]+)`",
               r'<font name="Consolas" size="8.8" color="#0B3D6B">\1</font>', t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", t)
    return t


def make_table(rows, width):
    header, body = rows[0], rows[1:]
    ncol = len(header)
    data = [[Paragraph(inline(c), THEAD) for c in header]]
    for r in body:
        r = r + [""] * (ncol - len(r))
        data.append([Paragraph(inline(c), TCELL) for c in r[:ncol]])
    t = Table(data, colWidths=[width / ncol] * ncol, repeatRows=1, hAlign="LEFT")
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), LIGHT))
    t.setStyle(TableStyle(style))
    return t


class Doc(BaseDocTemplate):
    def __init__(self, path, title, **kw):
        super().__init__(path, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                         topMargin=18 * mm, bottomMargin=17 * mm, title=title, **kw)

    def afterPage(self):
        c = self.canv
        c.saveState()
        c.setStrokeColor(RULE)
        c.setLineWidth(0.6)
        c.line(20 * mm, 12 * mm, A4[0] - 20 * mm, 12 * mm)
        c.setFont("Calibri", 7.4)
        c.setFillColor(GREY)
        c.drawString(20 * mm, 8.6 * mm, "Swift UMDAC Datathon 2026  ·  dashboard specification")
        c.drawRightString(A4[0] - 20 * mm, 8.6 * mm, f"page {self.page}")
        c.restoreState()


def parse(md, width):
    lines = md.splitlines()
    story = []
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln.strip():
            i += 1
            continue
        if ln.startswith("# "):
            story.append(Paragraph(inline(ln[2:]), ParagraphStyle(
                "title", fontName="Calibri-Bold", fontSize=21, leading=26, textColor=NAVY,
                spaceAfter=4)))
            story.append(Spacer(1, 2))
            story.append(Table([[""]], colWidths=[width], rowHeights=[1.6],
                               style=TableStyle([("BACKGROUND", (0, 0), (-1, -1), GOLD)])))
            story.append(Spacer(1, 8))
            i += 1
        elif ln.startswith("## "):
            story.append(Paragraph(inline(ln[3:]), H1))
            i += 1
        elif ln.startswith("### "):
            story.append(Paragraph(inline(ln[4:]), H2))
            i += 1
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                raw = lines[i].strip().strip("|")
                cells = [c.strip() for c in raw.split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                    rows.append(cells)
                i += 1
            if rows:
                block = [Spacer(1, 2), make_table(rows, width), Spacer(1, 7)]
                if story and isinstance(story[-1], Paragraph) and \
                        story[-1].style.name in ("h1", "h2"):
                    block.insert(0, story.pop())
                story.append(KeepTogether(block))
            continue
        elif ln.startswith("- "):
            items = []
            while i < len(lines) and lines[i].startswith("- "):
                items.append(Paragraph(inline(lines[i][2:].strip()), BULLET))
                i += 1
            story.append(ListFlowable([ListItem(x, leftIndent=13) for x in items],
                                      bulletType="bullet", start="•", bulletFontSize=8,
                                      leftIndent=10, bulletOffsetY=-0.6))
            story.append(Spacer(1, 4))
            continue
        elif re.match(r"^\d+\.\s", ln):
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s", lines[i]):
                items.append(Paragraph(inline(re.sub(r"^\d+\.\s", "", lines[i])), BULLET))
                i += 1
            story.append(ListFlowable([ListItem(x, leftIndent=15) for x in items],
                                      bulletType="1", bulletFormat="%s.",
                                      leftIndent=10, bulletFontName="Calibri-Bold",
                                      bulletFontSize=9.2, bulletColor=TEAL))
            story.append(Spacer(1, 4))
            continue
        elif ln.strip() == "---":
            story.append(Spacer(1, 4))
            story.append(Table([[""]], colWidths=[width], rowHeights=[0.7],
                               style=TableStyle([("BACKGROUND", (0, 0), (-1, -1), RULE)])))
            story.append(Spacer(1, 6))
            i += 1
        else:
            para = [ln.strip()]
            i += 1
            while i < len(lines) and lines[i].strip() and not re.match(
                    r"^(#|\||- |\d+\.\s|---)", lines[i]):
                para.append(lines[i].strip())
                i += 1
            kv = all(re.match(r"^\*\*[^*]+:\*\*", x) for x in para)
            text = "<br/>".join(inline(x) for x in para) if kv else inline(" ".join(para))
            story.append(Paragraph(text, BODY))
    return story


def main():
    src, dst = sys.argv[1], sys.argv[2]
    title = sys.argv[3] if len(sys.argv) > 3 else "Dashboard Specification"
    md = open(src, encoding="utf-8").read()
    width = A4[0] - 40 * mm
    doc = Doc(dst, title)

    def on_page(canv, d):
        canv.saveState()
        canv.setFillColor(NAVY)
        canv.rect(0, A4[1] - 7 * mm, A4[0], 7 * mm, stroke=0, fill=1)
        canv.setFillColor(GOLD)
        canv.rect(0, A4[1] - 7.9 * mm, A4[0], 0.9 * mm, stroke=0, fill=1)
        canv.restoreState()

    frame = Frame(20 * mm, 17 * mm, width, A4[1] - 35 * mm, id="body",
                  leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=on_page)])
    doc.build(parse(md, width))
    print(f"wrote {dst} ({os.path.getsize(dst)/1024:.0f} KB)")


if __name__ == "__main__":
    main()
