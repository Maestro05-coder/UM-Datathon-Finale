import duckdb, numpy as np
from scipy.optimize import minimize_scalar
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
df=c.execute(f"""select CURRENCY_CODE cur, USD_AMOUNT amt, count(*) n from '{p}'
group by 1,2 having count(*)>=30 order by cur, n desc""").df()
print('rows',len(df))
res=[]
for cur,g in df.groupby('cur'):
    g=g.sort_values('n',ascending=False).head(300)
    a=g.amt.values; w=g.n.values
    def cost(r):
        if r<=0: return 1e9
        x=a/r
        return np.average((x-np.round(x))**2, weights=w)
    # search around amount/round(local) heuristics
    base=np.median(a)/1000.0
    grid=np.linspace(base*0.5, base*1.5, 4000)
    costs=[cost(r) for r in grid]
    r0=grid[int(np.argmin(costs))]
    opt=minimize_scalar(cost,bounds=(r0*0.995,r0*1.005),method='bounded')
    r=opt.x
    x=a/r
    res.append((cur,len(g),r,np.average((x-np.round(x))**2,weights=w),np.average(a),np.average(np.round(x))))
import pandas as pd
out=pd.DataFrame(res,columns=['cur','nvals','rate','resid','meanamt','implied_local'])
print(out.sort_values('nvals',ascending=False).to_string(index=False))
