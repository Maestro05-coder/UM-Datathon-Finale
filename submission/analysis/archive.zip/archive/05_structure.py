import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))

q(f"""select TRANSACTION_TYPE_CODE t, PARTICIPANT_COUNT pc, count(*) n
from '{p}' group by 1,2 order by 1,2""",'type x participants')
q(f"""select TRANSACTION_TYPE_CODE t, CURRENCY_CONVERSION_COUNT cc, count(*) n
from '{p}' group by 1,2 order by 1,2 limit 60""",'type x conversions')
q(f"""select CONTINUITY_QFLAG q, TRANSACTION_TYPE_CODE t, count(*) n from '{p}' group by 1,2 order by 1,2""",'continuity x type')
q(f"""select avg(TOTAL_DURATION), min(TOTAL_DURATION), max(TOTAL_DURATION), median(TOTAL_DURATION),
quantile_cont(TOTAL_DURATION,0.99) p99 from '{p}'""",'duration')
q(f"""select PARTICIPANT_COUNT pc, count(*) n, avg(TOTAL_DURATION) avgdur, median(TOTAL_DURATION) meddur,
avg(CURRENCY_CONVERSION_COUNT) avgfx, avg(USD_AMOUNT) avgamt
from '{p}' group by 1 order by 1 limit 25""",'duration by participants')
q(f"""select CONTINUITY_QFLAG q, count(*) n, avg(TOTAL_DURATION) d, avg(PARTICIPANT_COUNT) pc, avg(CURRENCY_CONVERSION_COUNT) fx from '{p}' group by 1""",'continuity stats')
q(f"""select sum(case when participant_count = array_length(string_split(BIC8_PATH,';')) then 1 else 0 end) pc_eq_npaths,
sum(case when participant_count <> array_length(string_split(BIC8_PATH,';')) then 1 else 0 end) pc_ne_npaths,
sum(case when split_part(BIC8_PATH,';',1)=ORDERING_BIC8 then 1 else 0 end) first_ok,
sum(case when split_part(BIC8_PATH,';',-1)=BENEFICIARY_BIC8 then 1 else 0 end) last_ok,
sum(case when BIC8_PATH like '%...%' then 1 else 0 end) has_ellipsis,
sum(case when CONTINUITY_QFLAG='N' then 1 else 0 end) nflag,
sum(case when (BIC8_PATH like '%...%') = (CONTINUITY_QFLAG='N') then 1 else 0 end) cont_match
from '{p}'""",'path consistency')
q(f"""select ANOMALY_TYPE a, count(*) n, avg(USD_AMOUNT) amt, median(USD_AMOUNT) med,
avg(TOTAL_DURATION) dur, avg(PARTICIPANT_COUNT) pc, avg(CURRENCY_CONVERSION_COUNT) fx,
100.0*avg(case when ORDERING_TYPE='B' then 1 else 0 end) ob,
100.0*avg(case when BENEFICIARY_TYPE='B' then 1 else 0 end) bb,
100.0*avg(case when CONTINUITY_QFLAG='N' then 1 else 0 end) qn
from '{p}' group by 1 order by n desc""",'anomaly profile')
