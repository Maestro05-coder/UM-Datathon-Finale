import docx, os
p = "docs/Swift_Dataset_Anatomy_and_Generation_Rules.docx"
d = docx.Document(p)
print("size KB:", round(os.path.getsize(p)/1024, 1))
print("paragraphs:", len(d.paragraphs), "tables:", len(d.tables))
print("headings:")
for par in d.paragraphs:
    if par.style.name.startswith("Heading") and par.text.strip():
        print("  ", par.style.name, "|", par.text[:80])
print("\ntables shapes:", [(len(t.rows), len(t.columns)) for t in d.tables])
print("\nfirst 12 paragraphs:")
for par in d.paragraphs[:12]:
    if par.text.strip():
        print("  [", par.style.name, "]", par.text[:100])
# check nothing leaked raw markdown
bad = [par.text[:60] for par in d.paragraphs if "**" in par.text or par.text.strip().startswith("|")]
print("\nraw-markdown leaks:", bad[:5], "count:", len(bad))
