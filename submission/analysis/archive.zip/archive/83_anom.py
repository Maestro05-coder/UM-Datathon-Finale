"""Is anomaly injection per-payment or per-corridor? Rate vs volume relationship."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""
select substr(BENEFICIARY_BIC8,5,2) bc, count(*) total,
  count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'') anom,
  count(distinct ORDERING_BIC8) corridors
from '{P}' group by 1""").df()
d = d[d.total >= 200]
d['rate'] = d.anom / d.total
print("countries:", len(d))
print("corr(log anom, log total):", round(np.corrcoef(np.log(d.anom.clip(lower=1)), np.log(d.total))[0, 1], 3))
print("corr(log anom, log corridors):", round(np.corrcoef(np.log(d.anom.clip(lower=1)), np.log(d.corridors))[0, 1], 3))
print("corr(anom per corridor, total):", round(np.corrcoef(d.anom / d.corridors, d.total)[0, 1], 3))
print("\nanomalies per corridor: mean", round((d.anom / d.corridors).mean(), 3),
      " median", round((d.anom / d.corridors).median(), 3))
print("\ntop 10 by total:")
print(d.sort_values('total', ascending=False).head(10)[['bc', 'total', 'anom', 'corridors', 'rate']].round(4).to_string(index=False))
print("\ntop 10 by rate (total>=1000):")
print(d[d.total >= 1000].sort_values('rate', ascending=False).head(10)[['bc', 'total', 'anom', 'corridors', 'rate']].round(4).to_string(index=False))

# anomaly counts per typology: is each typology spread evenly across countries?
t = c.execute(f"""
select ANOMALY_TYPE a, substr(BENEFICIARY_BIC8,5,2) bc, count(*) n
from '{P}' where coalesce(ANOMALY_TYPE,'')<>'' group by 1,2""").df()
print("\n=== per-typology country spread ===")
for a, g in t.groupby('a'):
    print(f"{a:26s} countries={len(g):3d}  n={g.n.sum():5d}  top: {', '.join(g.nlargest(4,'n').bc)}")
