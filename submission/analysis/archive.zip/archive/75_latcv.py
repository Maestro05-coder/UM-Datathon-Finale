"""Cross-validated comparison of latency models (log space, out-of-sample)."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
d['oc'] = d.o.str[4:6]; d['bc'] = d.b.str[4:6]
y = np.log(d.med.values)


def backfit(train_idx, test_idx, cols, iters=40):
    tr = d.iloc[train_idx]; te = d.iloc[test_idx]
    levels = {col: np.union1d(tr[col].unique(), te[col].unique()) for col in cols}
    e = {col: pd.Series(0.0, index=levels[col]) for col in cols}
    ytr = y[train_idx]
    pred_tr = np.zeros(len(tr))
    for _ in range(iters):
        for col in cols:
            partial = pred_tr - e[col].reindex(tr[col]).values
            r = ytr - partial
            m = pd.Series(r).groupby(tr[col].values).mean()
            e[col] = m.reindex(levels[col]).fillna(0.0)
        pred_tr = sum(e[cc].reindex(tr[cc]).values for cc in cols)
    off = ytr.mean() - pred_tr.mean()
    pred_tr += off
    pred_te = sum(e[cc].reindex(te[cc]).values for cc in cols) + off
    return pred_tr, pred_te


rng = np.random.default_rng(0)
fold = rng.integers(0, 5, len(d))
for name, cols in [("country-pair additive", ['oc', 'bc']), ("bank additive", ['o', 'b'])]:
    oos = np.zeros(len(d))
    for k in range(5):
        tr_i = np.where(fold != k)[0]; te_i = np.where(fold == k)[0]
        _, ite = backfit(tr_i, te_i, cols)
        oos[te_i] = ite
    r2o = 1 - ((y - oos) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    rel = np.abs(np.exp(oos) - d.med) / d.med
    print(f"{name:26s} out-of-sample log R2={r2o:.3f}  median rel err={np.median(rel):.3f}  <25%={np.mean(rel<0.25):.2f}")
