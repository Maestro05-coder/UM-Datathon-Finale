import fitz
d = fitz.open("docs/Swift_Dataset_Anatomy_and_Generation_Rules.pdf")
for i in range(3, d.page_count):
    pix = d[i].get_pixmap(dpi=110)
    pix.save(f"analysis/prev_p{i+1}.png")
print("saved", d.page_count)
