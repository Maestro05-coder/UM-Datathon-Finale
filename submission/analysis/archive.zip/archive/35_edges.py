import duckdb, time
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
t0=time.time()
c.execute(f"""create or replace table src as
select row_number() over () rid, BIC8_PATH path, PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT cc,
 TOTAL_DURATION dur, TRANSACTION_TYPE_CODE t from '{p}'""")
print('src',time.time()-t0)
t0=time.time()
c.execute("""create or replace table edges as
with x as (select rid, string_split(path,';') p, dur, pc from src),
y as (select rid, dur, pc, unnest(list_zip(p[1:len(p)-1], p[2:len(p)])) e from x)
select e[1] a, e[2] b, count(*) n, count(distinct rid) npaths, median(dur) meddur, avg(dur) meandur
from y where e[1]<>'...' and e[2]<>'...' group by 1,2""")
print('edges',time.time()-t0)
print(c.execute("select count(*) nedges, sum(n) ntot from edges").fetchall())
print(c.execute("select * from edges order by n desc limit 30").df().to_string(index=False))
print(c.execute("select count(distinct a) na, count(distinct b) nb from edges").fetchall())
print(c.execute("select * from edges where n>100 order by meddur desc limit 20").df().to_string(index=False))
print(c.execute("select * from edges where n>100 order by meddur limit 20").df().to_string(index=False))
