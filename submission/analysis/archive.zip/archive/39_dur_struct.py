import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

# 1. does duration depend on endpoints only (same pair, pc2 vs pc3, and intermediate variation)?
print("=== same endpoint pair across participant counts ===")
print(c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, PARTICIPANT_COUNT pc, count(*) n,
       round(median(TOTAL_DURATION),1) med, round(stddev_samp(TOTAL_DURATION),1) sd,
       min(TOTAL_DURATION) mn, max(TOTAL_DURATION) mx,
       count(distinct BIC8_PATH) npaths
from '{p}' group by 1,2,3 having count(*)>=30
order by n desc limit 25""").df().to_string(index=False))

# 2. value histogram of duration for a big pair with high spread
print("\n=== duration histogram, 0001MQM0 -> 0009TNT0 ===")
print(c.execute(f"""
select (TOTAL_DURATION//100)*100 bucket, count(*) n
from '{p}' where ORDERING_BIC8='0001MQM0' and BENEFICIARY_BIC8='0009TNT0' group by 1 order by 1""").df().to_string(index=False))

# 3. global duration histogram (coarse)
print("\n=== global duration histogram, >600s ===")
print(c.execute(f"""
select (TOTAL_DURATION//300)*300 bucket, count(*) n from '{p}' where TOTAL_DURATION>600 group by 1 order by 1""").df().to_string(index=False))
