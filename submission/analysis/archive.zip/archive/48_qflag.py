import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

print("=== CONTINUITY_QFLAG crosstabs ===")
print(c.execute(f"""
select CONTINUITY_QFLAG q, count(*) n,
 round(avg(case when contains(BIC8_PATH,'...') then 1 else 0 end),4) ell_share,
 round(avg(CURRENCY_CONVERSION_COUNT),2) avgconv,
 round(avg(PARTICIPANT_COUNT),2) avgpc,
 round(avg(case when TRANSACTION_TYPE_CODE='Direct' then 1 else 0 end),3) direct_share
from '{p}' group by 1""").df().to_string(index=False))

print("\n=== QFLAG vs conversion count ===")
print(c.execute(f"""
select CURRENCY_CONVERSION_COUNT conv, sum(case when CONTINUITY_QFLAG='Y' then 1 else 0 end) y,
 sum(case when CONTINUITY_QFLAG='N' then 1 else 0 end) n from '{p}' group by 1 order by 1""").df().to_string(index=False))

print("\n=== QFLAG N examples ===")
print(c.execute(f"""
select BIC8_PATH, CURRENCY_CODE, CURRENCY_CONVERSION_COUNT conv, PARTICIPANT_COUNT pc,
 TRANSACTION_TYPE_CODE tt, ORDERING_TYPE ot, BENEFICIARY_TYPE bt
from '{p}' where CONTINUITY_QFLAG='N' using sample 8""").df().to_string(index=False))

print("\n=== QFLAG Y examples with ellipsis ===")
print(c.execute(f"""
select BIC8_PATH, CURRENCY_CODE, CURRENCY_CONVERSION_COUNT conv, PARTICIPANT_COUNT pc
from '{p}' where CONTINUITY_QFLAG='Y' and contains(BIC8_PATH,'...') using sample 5""").df().to_string(index=False))

print("\n=== TRANSACTION_TYPE_CODE x PARTICIPANT_COUNT ===")
print(c.execute(f"""
select TRANSACTION_TYPE_CODE tt, PARTICIPANT_COUNT pc, count(*) n from '{p}' group by 1,2 order by 1,2""").df().to_string(index=False))
