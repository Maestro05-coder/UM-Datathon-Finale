import duckdb
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
d = c.execute("""
select PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT fx, count(*) n,
       median(TOTAL_DURATION) med,
       quantile_cont(TOTAL_DURATION,0.1) p10,
       quantile_cont(TOTAL_DURATION,0.9) p90
from 'analysis/payments.parquet'
where PARTICIPANT_COUNT between 2 and 10 and CURRENCY_CONVERSION_COUNT between 0 and 6
group by 1,2 having count(*)>=300 order by 1,2""").df()
d.to_csv('dashboard/data/duration_by_pc_fx.csv', index=False)
print(d[d.fx == 1].round(1).to_string(index=False))
