import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

print("=== pc2: path shapes and durations (sample of pairs with multiple paths) ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, BIC8_PATH path, TOTAL_DURATION d, CONTINUITY_QFLAG q
 from '{p}' where PARTICIPANT_COUNT=2)
select o,b,path,q,count(*) n, round(median(d),1) med, round(stddev_samp(d),1) sd, min(d) mn, max(d) mx
from t group by 1,2,3,4
having count(*)>=20
order by n desc limit 30""").df().to_string(index=False))

print("\n=== pc2: ellipsis presence vs duration ===")
print(c.execute(f"""
select CONTINUITY_QFLAG q, count(*) n, round(median(TOTAL_DURATION),1) med,
 round(avg(case when TOTAL_DURATION<=60 then 1 else 0 end),3) fast_share
from '{p}' where PARTICIPANT_COUNT=2 group by 1""").df().to_string(index=False))

print("\n=== pc2: distinct path count distribution ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, count(distinct BIC8_PATH) npaths, count(*) n
 from '{p}' where PARTICIPANT_COUNT=2 group by 1,2)
select npaths, count(*) pairs, sum(n) rows from t group by 1 order by 1 limit 15""").df().to_string(index=False))
