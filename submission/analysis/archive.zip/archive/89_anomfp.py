"""Fingerprint each anomaly typology against structural features."""
import duckdb

c = duckdb.connect()
c.execute("SET threads=8")
c.execute("SET memory_limit='12GB'")
P = "analysis/payments.parquet"
q = f"""
with base as (
  select coalesce(ANOMALY_TYPE,'none') a,
         PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT fx,
         USD_AMOUNT amt, TOTAL_DURATION dur,
         ORDERING_TYPE ot, BENEFICIARY_TYPE bt,
         substr(ORDERING_BIC8,5,2)=substr(BENEFICIARY_BIC8,5,2) same_c,
         extract(hour from to_timestamp(EPOCH_SECONDS)) hr
  from '{P}'
)
select a, count(*) n,
       round(median(amt),0) med_amt, round(quantile_cont(amt,0.1),0) p10_amt,
       round(quantile_cont(amt,0.9),0) p90_amt,
       round(avg(pc),2) avg_pc, round(avg(fx),2) avg_fx,
       round(avg(case when same_c then 1 else 0 end),3) same_share,
       round(median(dur),0) med_dur,
       round(avg(hr),1) avg_hr
from base group by 1 order by n desc"""
print(c.execute(q).df().to_string(index=False))

print("\n=== pc distribution per typology ===")
print(c.execute(f"""
select a, pc, count(*) n from (
  select coalesce(ANOMALY_TYPE,'none') a, PARTICIPANT_COUNT pc from '{P}'
) group by 1,2 having count(*) > 40 order by 1,2""").df().pivot(index="a", columns="pc", values="n").fillna(0).astype(int).to_string())

print("\n=== top ordering countries per typology ===")
d = c.execute(f"""
select ANOMALY_TYPE a, substr(ORDERING_BIC8,5,2) oc, count(*) n
from '{P}' where coalesce(ANOMALY_TYPE,'')<>'' group by 1,2""").df()
for a, g in d.groupby("a"):
    tot = g.n.sum()
    top = g.nlargest(6, "n")
    print(f"{a:26s} " + "  ".join(f"{r.oc} {r.n/tot:.0%}" for r in top.itertuples()))
