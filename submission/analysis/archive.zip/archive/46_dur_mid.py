import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

print("=== participants / ellipses vs duration, same endpoints (top endpoint pairs) ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, PARTICIPANT_COUNT pc,
   (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell, TOTAL_DURATION d
 from '{p}')
select o,b,pc,ell,count(*) n, round(median(d),1) med from t
where o='0001MQM0' and b='0009TNT0' group by 1,2,3,4 order by pc,ell""").df().to_string(index=False))

print("\n=== global: ellipses vs duration by participant count ===")
print(c.execute(f"""
with t as (select PARTICIPANT_COUNT pc, (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell, TOTAL_DURATION d from '{p}')
select pc, least(ell,4) ell, count(*) n, round(median(d),1) med, round(avg(case when d<=60 then 1 else 0 end),3) fast
from t group by 1,2 order by 1,2""").df().to_string(index=False))

print("\n=== per-bank transit effect: mid 0309CHZ0, residual vs fitted a_o+c_b ===")
d=c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=40""").df()
banks=sorted(set(d.o)|set(d.b)); idx={b:i for i,b in enumerate(banks)}; nb=len(banks)
A=np.zeros((len(d),2*nb))
for r,(o,b) in enumerate(zip(d.o,d.b)):
    A[r,idx[o]]+=1; A[r,nb+idx[b]]+=1
sol,_,_,_=np.linalg.lstsq(A,d.med.values.astype(float),rcond=None)
ain={b:sol[idx[b]] for b in banks}; cout={b:sol[nb+idx[b]] for b in banks}

t3=c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, TOTAL_DURATION d,
   string_split(BIC8_PATH,';') parts
 from '{p}' where PARTICIPANT_COUNT=3)
select o, parts[2] mid, b, count(*) n, median(d) med, stddev_samp(d) sd from t group by 1,2,3 having count(*)>=20""").df()
t3=t3[t3.mid!='...']
t3['base']=t3.o.map(ain)+t3.b.map(cout)
t3['excess']=t3.med-t3.base
print(t3.sort_values('n',ascending=False).head(20)[['o','mid','b','n','med','base','excess']].to_string(index=False))
print("\nexcess by mid (banks with >=4 triples):")
gg=t3.groupby('mid').excess.agg(['median','std','count']).reset_index()
gg=gg[gg['count']>=4].sort_values('count',ascending=False)
print(gg.head(20).to_string(index=False))
