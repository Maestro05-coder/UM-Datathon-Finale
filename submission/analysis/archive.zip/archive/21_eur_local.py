import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
# rate table from modal amount in [950,1300] per day (assume 1000 local)
df=c.execute(f"""
with x as (select date_trunc('day',to_timestamp(EPOCH_SECONDS)) d, USD_AMOUNT a, count(*) n
 from '{p}' where CURRENCY_CODE='EUR' and USD_AMOUNT between 950 and 1300 group by 1,2),
y as (select d,a,n,row_number() over(partition by d order by n desc) rk from x)
select d, a/1000.0 rate from y where rk=1 order by d""").df()
print(df.head())
c.execute("create or replace temp table eurrate as select * from df")
# most common implied local amounts
q=f"""
select round(USD_AMOUNT / r.rate, 2) local, count(*) n
from '{p}' p join eurrate r on date_trunc('day',to_timestamp(p.EPOCH_SECONDS))=r.d
where CURRENCY_CODE='EUR'
group by 1 order by n desc limit 40"""
print(c.execute(q).df().to_string(index=False))
q2=f"""
select round(USD_AMOUNT / r.rate, 0) local, count(*) n
from '{p}' p join eurrate r on date_trunc('day',to_timestamp(p.EPOCH_SECONDS))=r.d
where CURRENCY_CODE='EUR' and USD_AMOUNT<100000
group by 1 order by n desc limit 40"""
print(c.execute(q2).df().to_string(index=False))
# check integer-ness distribution
q3=f"""select round(USD_AMOUNT / r.rate,0) ilocal, count(*) n,
 avg(abs(USD_AMOUNT/r.rate - round(USD_AMOUNT/r.rate))) err
from '{p}' p join eurrate r on date_trunc('day',to_timestamp(p.EPOCH_SECONDS))=r.d
where CURRENCY_CODE='EUR' group by 1 order by n desc limit 20"""
print(c.execute(q3).df().to_string(index=False))
