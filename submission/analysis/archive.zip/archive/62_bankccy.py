import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
def cc(col): return f"substr({col},5,2)"

# per-bank modal payment currency (as ordering bank, and as beneficiary bank)
bank_cur = c.execute(f"""
with o as (select ORDERING_BIC8 bic, CURRENCY_CODE cur, count(*) n,
       row_number() over (partition by ORDERING_BIC8 order by count(*) desc) rk
       from '{P}' group by 1,2),
     b as (select BENEFICIARY_BIC8 bic, CURRENCY_CODE cur, count(*) n,
       row_number() over (partition by BENEFICIARY_BIC8 order by count(*) desc) rk
       from '{P}' group by 1,2)
select o.bic, o.cur cur_o, o.n n_o, b.cur cur_b, b.n n_b,
       (select sum(n) from o o2 where o2.bic=o.bic) tot_o
from o join b on o.bic=b.bic where o.rk=1 and b.rk=1""").df()
print("banks:",len(bank_cur)," share of payments where bank's modal ccy is >=90% of its volume:",
      round(((bank_cur.n_o/bank_cur.tot_o)>=0.9).mean(),3))
print("distribution of modal-currency concentration (n_o/tot_o):")
print((bank_cur.n_o/bank_cur.tot_o).describe().round(3).to_string())
bank_cur.to_csv('dashboard/data/bank_currency.csv',index=False)

# test: conv == (pay_cur != modal ccy of beneficiary bank), on pc2
d = c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, CURRENCY_CODE pay, CURRENCY_CONVERSION_COUNT fx
from '{P}' where PARTICIPANT_COUNT=2 using sample 400000""").df()
m = dict(zip(bank_cur.bic, bank_cur.cur_b))
mo = dict(zip(bank_cur.bic, bank_cur.cur_o))
d['cur_b']=d.b.map(m); d['cur_o']=d.o.map(mo)
d = d.dropna(subset=['cur_b','cur_o'])
print("\n=== candidate rules for pc2 conversion count ===")
tests = {
 'pay != modal ccy of beneficiary bank': (d.pay!=d.cur_b).astype(int),
 'pay != modal ccy of ordering bank'    : (d.pay!=d.cur_o).astype(int),
 'modal o != modal b'                   : (d.cur_o!=d.cur_b).astype(int),
}
for k,v in tests.items():
    print(f"  {k:42s} match={ (d.fx==v).mean():.4f}")

# where the best rule fails, what is different?
best = (d.pay!=d.cur_b).astype(int)
bad = d[d.fx!=best]
print("\nmismatch rate:",round(len(bad)/len(d),4))
print(bad.groupby(['fx']).size().to_string())

# alternative: each node currency = pay_cur for origin, country home for others (already covered)

# ---------- binomial fit for fx count ----------
from math import comb
fx = pd.read_csv('dashboard/data/fx_by_participants.csv')
print("\n=== binomial fit check (q=0.851) ===")
q=0.851
rows=[]
for pc,g in fx.groupby('pc'):
    tot=g.n.sum()
    for k in range(0,min(pc,8)):
        obs = g.loc[g.fx==k,'n'].sum()/tot
        pred = comb(pc-1,k)*(q**k)*((1-q)**(pc-1-k))
        rows.append((pc,k,obs,pred))
r=pd.DataFrame(rows,columns=['pc','fx','obs','pred'])
r['diff']=r.obs-r.pred
print(r[r.pc<=5].round(4).to_string(index=False))
print("max |diff|:",round(r['diff'].abs().max(),4),"mean |diff|:",round(r['diff'].abs().mean(),4))
r.to_csv('dashboard/data/fx_binomial_fit.csv',index=False)
