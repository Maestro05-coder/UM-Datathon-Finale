"""Markdown -> DOCX exporter tuned for the analysis notes in this repo.

Usage:  python analysis/md2docx.py <input.md> <output.docx> ["Doc title"]
"""
import re, sys, os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ACCENT = RGBColor(0x0B, 0x3D, 0x6B)      # deep navy
ACCENT2 = RGBColor(0x1F, 0x6F, 0x8B)     # teal
GREY = RGBColor(0x59, 0x59, 0x59)
BODY_FONT = "Calibri"
MONO_FONT = "Consolas"

# characters Calibri lacks -> readable fallbacks
GLYPH_FIX = {"\u27fa": "\u21d4", "\u27f9": "\u21d2", "\u226b": "\u00bb", "\u226a": "\u00ab"}


def fix(t):
    for k, v in GLYPH_FIX.items():
        t = t.replace(k, v)
    return t


# ---------------------------------------------------------------- inline runs
INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+`|\*[^*]+\*)")


def _emit(par, text, size, color=None, bold=False, italic=False):
    """Emit text, honouring `code` spans (may be nested inside bold/italic)."""
    for part in re.split(r"(`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("`") and part.endswith("`") and len(part) > 2:
            r = par.add_run(part[1:-1])
            r.font.name = MONO_FONT
            r.font.size = Pt(size - 1)
            r.font.color.rgb = RGBColor(0x8B, 0x1A, 0x1A)
            _shade_run(r, "F2F2F2")
            if bold:
                r.bold = True
            if italic:
                r.italic = True
        else:
            r = par.add_run(part)
            r.font.name = BODY_FONT
            r.font.size = Pt(size)
            if color is not None:
                r.font.color.rgb = color
            if bold:
                r.bold = True
            if italic:
                r.italic = True


def add_runs(par, text, size=10.5, color=None, bold=False, italic=False):
    text = fix(text)
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            _emit(par, part[2:-2], size, color, bold=True, italic=italic)
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            _emit(par, part[1:-1], size, color, bold=bold, italic=True)
        else:
            _emit(par, part, size, color, bold=bold, italic=italic)


def _shade_run(run, hex_fill):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_fill)
    run._element.get_or_add_rPr().append(shd)


def _shade_cell(cell, hex_fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tcPr.append(shd)


def _cell_margins(table, top=60, bottom=60, left=90, right=90):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for side, val in (("top", top), ("bottom", bottom), ("left", left), ("right", right)):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:w"), str(val)); el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def _repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader"); el.set(qn("w:val"), "true")
    trPr.append(el)


def _no_split(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:cantSplit"); el.set(qn("w:val"), "true")
    trPr.append(el)


def _box(par, fill, border="BFBFBF"):
    """Shade the whole paragraph and draw a thin box around it."""
    pPr = par._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    for side in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), "single"); el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "4"); el.set(qn("w:color"), border)
        pbdr.append(el)
    pPr.append(pbdr)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    pPr.append(shd)


def _fix_table_layout(table, header, rows, total_cm=16.6):
    """Fixed layout with column widths proportional to content length."""
    tblPr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    tblW = OxmlElement("w:tblW")
    tblW.set(qn("w:w"), str(int(total_cm / 2.54 * 1440)))
    tblW.set(qn("w:type"), "dxa")
    tblPr.append(tblW)

    cols = len(header)
    maxlen = []
    for j in range(cols):
        vals = [len(header[j].replace("`", ""))] + [
            len(r[j].replace("`", "").replace("**", "")) if j < len(r) else 0 for r in rows]
        maxlen.append(max(6, min(sorted(vals)[int(len(vals) * 0.9)] if vals else 8, 60)))
    weights = [m ** 0.72 for m in maxlen]
    s = sum(weights)
    widths = [total_cm * w / s for w in weights]
    widths = [max(w, 1.5) for w in widths]
    s2 = sum(widths)
    widths = [w * total_cm / s2 for w in widths]

    for row in table.rows:
        for j, cell in enumerate(row.cells):
            cell.width = Cm(widths[j])
        _no_split(row)


def _keep_with_next(par):
    par.paragraph_format.keep_with_next = True


# ---------------------------------------------------------------- blocks
def build(doc, md):
    lines = md.split("\n")
    i, n = 0, len(lines)
    first_h1 = True

    while i < n:
        raw = lines[i]
        line = raw.rstrip()
        s = line.strip()

        # ---- fenced code
        if s.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.15)
            p.paragraph_format.right_indent = Cm(0.15)
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(10)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.keep_together = True
            _box(p, "F4F6F8", "D6DEE7")
            r = p.add_run(fix("\n".join(buf)))
            r.font.name = MONO_FONT
            r.font.size = Pt(8.5)
            r.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
            continue

        # ---- table
        if s.startswith("|") and i + 1 < n and re.match(r"^\|[\s:|-]+\|$", lines[i + 1].strip()):
            header = [c.strip() for c in s.strip("|").split("|")]
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            table = doc.add_table(rows=1, cols=len(header))
            table.style = "Table Grid"
            table.alignment = WD_TABLE_ALIGNMENT.LEFT
            table.autofit = True
            _cell_margins(table)
            hdr = table.rows[0]
            _repeat_header(hdr)
            for j, h in enumerate(header):
                cell = hdr.cells[j]
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.space_after = Pt(2)
                add_runs(p, h, size=9.5, color=RGBColor(0xFF, 0xFF, 0xFF), bold=True)
                _shade_cell(cell, "0B3D6B")
            for k, row in enumerate(rows):
                cells = table.add_row().cells
                _no_split(table.rows[-1])
                for j, val in enumerate(row[:len(header)]):
                    cells[j].text = ""
                    p = cells[j].paragraphs[0]
                    p.paragraph_format.space_after = Pt(2)
                    add_runs(p, val, size=9.5)
                    if k % 2 == 1:
                        _shade_cell(cells[j], "F3F6F9")
            _fix_table_layout(table, header, rows)
            doc.add_paragraph().paragraph_format.space_after = Pt(4)
            continue

        # ---- headings
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            level, txt = len(m.group(1)), m.group(2).strip()
            if level == 1 and first_h1:
                first_h1 = False
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(4)
                add_runs(p, txt, size=24, color=ACCENT, bold=True)
                # rule under title
                pr = p._p.get_or_add_pPr()
                pbdr = OxmlElement("w:pBdr")
                bottom = OxmlElement("w:bottom")
                bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "12")
                bottom.set(qn("w:space"), "6"); bottom.set(qn("w:color"), "0B3D6B")
                pbdr.append(bottom); pr.append(pbdr)
            else:
                p = doc.add_heading(level=min(level - 1, 4) if level > 1 else 1)
                p.text = ""
                size = {1: 17, 2: 13.5, 3: 11.8, 4: 11}.get(level, 10.5)
                add_runs(p, txt, size=size, color=ACCENT if level <= 2 else ACCENT2, bold=True)
                p.paragraph_format.space_before = Pt(14 if level <= 2 else 10)
                p.paragraph_format.space_after = Pt(4)
                _keep_with_next(p)
            i += 1
            continue

        # ---- horizontal rule
        if re.match(r"^(-{3,}|\*{3,}|_{3,})$", s):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(8)
            pr = p._p.get_or_add_pPr()
            pbdr = OxmlElement("w:pBdr")
            bottom = OxmlElement("w:bottom")
            bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "6")
            bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), "BFBFBF")
            pbdr.append(bottom); pr.append(pbdr)
            i += 1
            continue

        # ---- blockquote
        if s.startswith(">"):
            txt = s.lstrip(">").strip()
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.6)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(8)
            pr = p._p.get_or_add_pPr()
            pbdr = OxmlElement("w:pBdr")
            left = OxmlElement("w:left")
            left.set(qn("w:val"), "single"); left.set(qn("w:sz"), "18")
            left.set(qn("w:space"), "8"); left.set(qn("w:color"), "1F6F8B")
            pbdr.append(left); pr.append(pbdr)
            add_runs(p, txt, size=10, color=GREY, italic=True)
            i += 1
            continue

        # ---- lists
        m = re.match(r"^(\s*)[-*+]\s+(.*)$", raw)
        if m:
            indent = len(m.group(1)) // 2
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.left_indent = Cm(0.63 + 0.5 * indent)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.line_spacing = 1.08
            add_runs(p, m.group(2))
            i += 1
            continue

        m = re.match(r"^(\s*)(\d+)[.)]\s+(.*)$", raw)
        if m:
            indent = len(m.group(1)) // 2
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.left_indent = Cm(0.63 + 0.5 * indent)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.line_spacing = 1.08
            add_runs(p, m.group(3))
            i += 1
            continue

        # ---- blank
        if not s:
            i += 1
            continue

        # ---- paragraph (join consecutive non-special lines)
        buf = [s]
        i += 1
        while i < n:
            nxt = lines[i].rstrip()
            ns = nxt.strip()
            if (not ns or ns.startswith(("#", "|", ">", "```", "- ", "* ", "+ "))
                    or re.match(r"^\d+[.)]\s", ns) or re.match(r"^(-{3,}|\*{3,}|_{3,})$", ns)):
                break
            buf.append(ns)
            i += 1
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing = 1.12
        add_runs(p, " ".join(buf))


# ---------------------------------------------------------------- chrome
def add_field(par, instr):
    r = par.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), instr)
    r._element.addnext(fld)


def setup(doc, subtitle):
    sec = doc.sections[0]
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(1.9)
    sec.left_margin = Cm(2.1)
    sec.right_margin = Cm(2.1)

    style = doc.styles["Normal"]
    style.font.name = BODY_FONT
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)

    # header
    hp = sec.header.paragraphs[0]
    hp.text = ""
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = hp.add_run(subtitle)
    r.font.size = Pt(8)
    r.font.name = BODY_FONT
    r.font.color.rgb = GREY

    # footer with page number
    fp = sec.footer.paragraphs[0]
    fp.text = ""
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run("Page ")
    r.font.size = Pt(8); r.font.color.rgb = GREY
    add_field(fp, "PAGE")
    r2 = fp.add_run(" of ")
    r2.font.size = Pt(8); r2.font.color.rgb = GREY
    add_field(fp, "NUMPAGES")


def main():
    src, dst = sys.argv[1], sys.argv[2]
    subtitle = sys.argv[3] if len(sys.argv) > 3 else "Swift UMDAC Datathon 2026 — working note"
    md = open(src, encoding="utf-8").read()
    doc = Document()
    setup(doc, subtitle)
    build(doc, md)
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
    doc.save(dst)
    print("written:", dst)


if __name__ == "__main__":
    main()
