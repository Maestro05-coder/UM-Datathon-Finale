"""Compute every aggregate needed by the 10 dashboard panels -> dashboard/data/*.csv
Prints the key numbers so the claims can be checked before plotting.
"""
import duckdb, pandas as pd, numpy as np, os, json

c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
OUT = 'dashboard/data'; os.makedirs(OUT, exist_ok=True)
pd.set_option('display.width', 200)

def save(df, name):
    df.to_csv(f"{OUT}/{name}.csv", index=False)
    return df

def cc(col): return f"substr({col},5,2)"

# ---------------------------------------------------------------- country -> home currency
home = c.execute(f"""
select {cc('ORDERING_BIC8')} cc, CURRENCY_CODE cur, count(*) n,
       row_number() over (partition by {cc('ORDERING_BIC8')} order by count(*) desc) rk
from '{P}' group by 1,2 qualify rk=1""").df()
home_map = dict(zip(home.cc, home.cur))
home_map_df = save(home[['cc','cur','n']].rename(columns={'cur':'home_currency'}), 'country_home_currency')
print("countries with home currency:", len(home_map))

# ---------------------------------------------------------------- 1. currency
cur = c.execute(f"""
select {cc('ORDERING_BIC8')} oc, CURRENCY_CODE cur, count(*) n
from '{P}' group by 1,2""").df()
cur['home'] = cur.oc.map(home_map)
cur['is_local'] = cur.cur == cur.home
g = cur.groupby('oc').agg(n=('n','sum'), local=('n', lambda s: cur.loc[s.index][cur.loc[s.index,'is_local']].n.sum()))
g['local_share'] = g.local / g.n
g = g.sort_values('n', ascending=False)
save(g.reset_index(), 'currency_local_share')
print("\n=== local-currency share, top 15 countries by volume ===")
print(g.head(15)[['n','local_share']].round(4).to_string())

foreign = cur[~cur.is_local].groupby('cur').n.sum().sort_values(ascending=False)
print("\n=== currency mix of NON-local payments (top 12) ===")
print((foreign.head(12)/foreign.sum()).round(4).to_string())
save(foreign.reset_index().rename(columns={'cur':'currency','n':'payments'}), 'currency_foreign_mix')

# ---------------------------------------------------------------- 2. amounts
amt = c.execute(f"""
select ORDERING_TYPE ot, BENEFICIARY_TYPE bt, USD_AMOUNT a from '{P}' where USD_AMOUNT>0""").df()
amt['pair'] = amt.ot + '→' + amt.bt
q = amt.groupby('pair').a.agg(['count','median','mean',
     lambda s: s.quantile(.05), lambda s: s.quantile(.95)]).rename(
     columns={'<lambda_0>':'p05','<lambda_1>':'p95'})
print("\n=== amount by party pair ===")
print(q.round(1).to_string())
save(q.reset_index(), 'amount_pair_stats')
ratios = {'vs_CC': {k: round(v/q.loc['C→C','median'],2) for k,v in q['median'].items()},
          'vs_BB': {k: round(v/q.loc['B→B','median'],3) for k,v in q['median'].items()}}
print("ratio vs C→C:", ratios['vs_CC'])
print("ratio vs B→B:", ratios['vs_BB'])

# ---------------------------------------------------------------- 3. participants by tx type
pc = c.execute(f"""
select TRANSACTION_TYPE_CODE tt, PARTICIPANT_COUNT pc, count(*) n from '{P}'
group by 1,2 order by 1,2""").df()
save(pc, 'participants_by_type')
print("\n=== participants by type (n, share within type) ===")
pc['share'] = pc.n / pc.groupby('tt').n.transform('sum')
print(pc[pc.pc<=8].to_string(index=False))

# ---------------------------------------------------------------- 4. gap rate
gap = c.execute(f"""
with t as (select PARTICIPANT_COUNT pc,
   (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell
 from '{P}')
select pc, count(*) n, avg(case when ell>0 then 1 else 0 end) gap_rate,
       avg(ell) mean_gaps, max(ell) max_gaps
from t where pc between 2 and 12 group by 1 order by 1""").df()
save(gap, 'gap_rate_by_participants')
print("\n=== gap rate by participant count ===")
print(gap.round(4).to_string(index=False))

# fit p from P(gap)=1-(1-p)^(n-1) using pc=2
p_hat = gap.loc[gap.pc==2,'gap_rate'].iloc[0]
gap['pred_p2'] = 1-(1-p_hat)**(gap.pc-1)
print(f"\nper-hop hide prob p = {p_hat:.4f}; predicted vs observed:")
print(gap[['pc','gap_rate','pred_p2']].round(4).to_string(index=False))

# ---------------------------------------------------------------- 5. fx count by participants
fx = c.execute(f"""
select PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT fx, count(*) n from '{P}'
where PARTICIPANT_COUNT between 2 and 9 group by 1,2 order by 1,2""").df()
save(fx, 'fx_by_participants')
print("\n=== mean conversions by participants + implied per-hop q ===")
m = fx.groupby('pc').apply(lambda d: (d.fx*d.n).sum()/d.n.sum(), include_groups=False)
out = pd.DataFrame({'mean_fx': m, 'implied_q': m/(m.index-1)})
print(out.round(4).to_string())

# per-hop change probability by ordering country (pc2 only, deterministic check)
fx2 = c.execute(f"""
select {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc,
       avg(CURRENCY_CONVERSION_COUNT) p_conv, count(*) n
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=200""").df()
save(fx2, 'fx_pair_heat')
print("\npc2 conversion prob: share of pair-cells that are 0 or 1 exactly:",
      round(((fx2.p_conv<0.001)|(fx2.p_conv>0.999)).mean(),4))

# ---------------------------------------------------------------- 6. duration
dur = c.execute(f"""
select PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT fx, count(*) n,
       median(TOTAL_DURATION) med, quantile_cont(TOTAL_DURATION,0.9) p90
from '{P}' where PARTICIPANT_COUNT between 2 and 10 and CURRENCY_CONVERSION_COUNT between 0 and 6
group by 1,2 having count(*)>=300""").df()
save(dur, 'duration_by_pc_fx')
print("\n=== duration (fx=1 fixed) ===")
print(dur[dur.fx==1].round(1).to_string(index=False))

# ---------------------------------------------------------------- 7. time
hour = c.execute(f"""
select {cc('ORDERING_BIC8')} oc, (EPOCH_SECONDS//3600)%24 h, count(*) n from '{P}'
group by 1,2""").df()
piv = hour.pivot(index='oc', columns='h', values='n').fillna(0)
piv = piv.loc[piv.sum(1).sort_values(ascending=False).head(40).index]
save(piv.reset_index(), 'hour_by_country')

daily = c.execute(f"""
select (EPOCH_SECONDS//86400)*86400 day, count(*) n from '{P}' group by 1 order by 1""").df()
daily['date'] = pd.to_datetime(daily.day, unit='s', utc=True)
daily['dow'] = daily.date.dt.dayofweek
save(daily, 'daily_volume')
print("\n=== daily volume: min/max/mean ===")
print(daily.n.describe().round(0).to_string())

# ---------------------------------------------------------------- 8. anomalies
anom = c.execute(f"""
select ANOMALY_TYPE a, ORDERING_TYPE ot, BENEFICIARY_TYPE bt, count(*) n
from '{P}' where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2,3""").df()
save(anom, 'anomaly_typology_pair')
print("\n=== anomaly typology x party pair ===")
print(anom.pivot_table(index='a', columns=['ot','bt'], values='n', fill_value=0).to_string())

anom_b = c.execute(f"""
select {cc('BENEFICIARY_BIC8')} bc, ANOMALY_TYPE a, count(*) n from '{P}'
where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2""").df()
tot_b = c.execute(f"select {cc('BENEFICIARY_BIC8')} bc, count(*) n from '{P}' group by 1").df()
ab = anom_b.groupby('bc').n.sum().to_frame('anom').join(tot_b.set_index('bc').n.rename('total')).fillna(0)
ab['rate'] = ab.anom/ab.total
ab = ab.sort_values('anom', ascending=False)
save(ab.reset_index(), 'anomaly_by_beneficiary_country')
print("\n=== top anomaly beneficiary countries ===")
print(ab.head(12).round(5).to_string())

# ---------------------------------------------------------------- 9. banks & intermediaries
banks = c.execute(f"""
select {cc('ORDERING_BIC8')} cc, count(distinct ORDERING_BIC8) b from '{P}' group by 1 order by 2 desc""").df()
save(banks, 'bank_count_by_country')
print("\n=== banks per country top 10 ===")
print(banks.head(10).to_string(index=False))

inter = c.execute(f"""
with t as (select string_split(BIC8_PATH,';') parts from '{P}'
           where PARTICIPANT_COUNT>=3 and not contains(BIC8_PATH,'...'))
select unnest(list_slice(parts,2,len(parts)-1)) bic, count(*) n from t group by 1""").df()
inter = inter.sort_values('n', ascending=False).reset_index(drop=True)
inter['share'] = inter.n/inter.n.sum()
inter['cum'] = inter.share.cumsum()
save(inter, 'intermediary_concentration')
print("\n=== intermediary concentration ===")
print(inter.head(10).to_string(index=False))
for k in (10,100,1000):
    print(f"top {k} intermediaries = {inter.cum.iloc[min(k,len(inter))-1]:.3f} of intermediate appearances")

# ---------------------------------------------------------------- 10. country token agreement
tok = c.execute(f"""
select
  regexp_extract(ORDERING_TOKENS,'country_code:([A-Z]{{2}})',1) otok,
  regexp_extract(BENEFICIARY_TOKENS,'country_code:([A-Z]{{2}})',1) btok,
  {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc
from '{P}'""").df()
o_has = tok.otok != ''
b_has = tok.btok != ''
res = {
 'ordering_token_present': float(o_has.mean()),
 'ordering_match_when_present': float((tok.loc[o_has,'otok']==tok.loc[o_has,'oc']).mean()),
 'beneficiary_token_present': float(b_has.mean()),
 'beneficiary_match_when_present': float((tok.loc[b_has,'btok']==tok.loc[b_has,'bc']).mean()),
 'beneficiary_match_any_token_equals_any_country': float((tok.btok.isin(set(tok.bc))).mean()),
}
print("\n=== country-token agreement ===")
print(json.dumps(res, indent=2))
json.dump(res, open(f"{OUT}/token_agreement.json","w"), indent=2)
print("\ndone")
