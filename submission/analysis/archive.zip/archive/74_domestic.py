"""Row-level latency patterns: domestic vs cross-border, and country effects."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
def cc(x): return f"substr({x},5,2)"

print("=== pc2 row-level: domestic vs cross-border ===")
q = c.execute(f"""
select {cc('ORDERING_BIC8')}={cc('BENEFICIARY_BIC8')} same_cc, count(*) n,
       median(TOTAL_DURATION) med, quantile_cont(TOTAL_DURATION,0.9) p90
from '{P}' where PARTICIPANT_COUNT=2 group by 1""").df()
print(q.round(1).to_string(index=False))

print("\n=== ordering-country median duration (pc2, >=20k rows) ===")
q = c.execute(f"""
select {cc('ORDERING_BIC8')} oc, count(*) n, median(TOTAL_DURATION) med
from '{P}' where PARTICIPANT_COUNT=2 group by 1 having count(*)>=20000
order by med desc""").df()
print("slowest:"); print(q.head(10).round(0).to_string(index=False))
print("fastest:"); print(q.tail(10).round(0).to_string(index=False))

print("\n=== beneficiary-country median duration (pc2) ===")
q2 = c.execute(f"""
select {cc('BENEFICIARY_BIC8')} bc, count(*) n, median(TOTAL_DURATION) med
from '{P}' where PARTICIPANT_COUNT=2 group by 1 having count(*)>=20000
order by med desc""").df()
print("slowest:"); print(q2.head(8).round(0).to_string(index=False))
print("fastest:"); print(q2.tail(8).round(0).to_string(index=False))

print("\n=== does the country pair explain row-level latency? (pc2, cells >=5000) ===")
q3 = c.execute(f"""
select {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc, count(*) n,
       median(TOTAL_DURATION) med, quantile_cont(TOTAL_DURATION,0.1) p10,
       quantile_cont(TOTAL_DURATION,0.9) p90
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=5000
order by n desc""").df()
print("cells:", len(q3))
print(q3.head(12).round(0).to_string(index=False))
print("\nspread of cell medians:", q3.med.describe(percentiles=[.05,.5,.95]).round(0).to_dict())

print("\n=== sanity: top cell by volume, compare with its banks ===")
top = c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, count(*) n, median(TOTAL_DURATION) med
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 order by n desc limit 8""").df()
print(top.to_string(index=False))
