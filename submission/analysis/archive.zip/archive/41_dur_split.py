import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
def cc(col): return f"substr({col},5,2)"

print("=== MQ->CH pc2 rows: what separates fast from slow? ===")
print(c.execute(f"""
select case when TOTAL_DURATION<=60 then 'fast' else 'slow' end mode, count(*) n,
  round(median(USD_AMOUNT),0) amt, round(median(CURRENCY_CONVERSION_COUNT),2) conv,
  round(avg(CURRENCY_CONVERSION_COUNT),2) avgconv, round(median(EPOCH_SECONDS/3600%24),1) hr,
  count(distinct CURRENCY_CODE) ncur, min(TOTAL_DURATION) mn, max(TOTAL_DURATION) mx
from '{p}' where ORDERING_BIC8='0001MQM0' and BENEFICIARY_BIC8='0309CHZ0' and PARTICIPANT_COUNT=2
group by 1""").df().to_string(index=False))

print("\n=== MQ->TN pc2: duration buckets detail ===")
print(c.execute(f"""
select case when TOTAL_DURATION<1600 then 'a_<1600' when TOTAL_DURATION<1700 then 'b_1600-1700'
  when TOTAL_DURATION<2000 then 'c_1700-2000' else 'd_>2000' end b, count(*) n,
  round(median(USD_AMOUNT),0) amt, round(avg(CURRENCY_CONVERSION_COUNT),2) conv,
  round(median(EPOCH_SECONDS/3600%24),1) hr, count(distinct CURRENCY_CODE) ncur
from '{p}' where ORDERING_BIC8='0001MQM0' and BENEFICIARY_BIC8='0009TNT0' and PARTICIPANT_COUNT=2
group by 1 order by 1""").df().to_string(index=False))

print("\n=== within-country-pair spread of bank-pair medians (US-US) ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, count(*) n, median(TOTAL_DURATION) med
from '{p}' where PARTICIPANT_COUNT=2 and {cc('ORDERING_BIC8')}='US' and {cc('BENEFICIARY_BIC8')}='US'
group by 1,2 having count(*)>=100)
select count(*) pairs, round(min(med),1) mn, round(quantile_cont(med,0.1),1) p10, round(median(med),1) p50,
 round(quantile_cont(med,0.9),1) p90, round(max(med),1) mx from t""").df().to_string(index=False))

print("\n=== distribution of pc2 bank-pair medians, global (n>=200) ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, count(*) n, median(TOTAL_DURATION) med
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=200)
select round(med/100)*100 bucket, count(*) npairs, sum(n) rows from t group by 1 order by 1""").df().to_string(index=False))
