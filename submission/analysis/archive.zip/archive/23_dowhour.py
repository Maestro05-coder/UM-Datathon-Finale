import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select dayname(to_timestamp(EPOCH_SECONDS)) dow, ORDERING_TYPE o, count(*) n,
round(100.0*count(*)/sum(count(*)) over (partition by ORDERING_TYPE),2) pct
from '{p}' group by 1,2 order by 2,1""",'dow by ordering type')
q(f"""select dayname(to_timestamp(EPOCH_SECONDS)) dow, BENEFICIARY_TYPE b, count(*) n,
round(100.0*count(*)/sum(count(*)) over (partition by BENEFICIARY_TYPE),2) pct
from '{p}' group by 1,2 order by 2,1""",'dow by benef type')
q(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, ORDERING_TYPE o, count(*) n from '{p}' group by 1,2 order by 2,1""",'hour by ordering type')
q(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, BENEFICIARY_TYPE b, count(*) n from '{p}' group by 1,2 order by 2,1""",'hour by benef type')
for ct in ['US','GB','CH','DE','SG','JP','CN','AU','MY','IN','BR','AE','ZA']:
    print('#####',ct)
    print(c.execute(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, count(*) n from '{p}'
    where substr(ORDERING_BIC8,5,2)='{ct}' group by 1 order by 1""").df().T.to_string())
