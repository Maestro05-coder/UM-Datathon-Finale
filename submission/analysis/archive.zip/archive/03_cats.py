import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
cols=['CURRENCY_CODE','CONTINUITY_QFLAG','TRANSACTION_TYPE_CODE','ORDERING_TYPE','BENEFICIARY_TYPE','ANOMALY_TYPE','CURRENCY_CONVERSION_COUNT','PARTICIPANT_COUNT']
for col in cols:
    print('===',col)
    df=c.execute(f"""select {col} v, count(*) n, round(100.0*count(*)/1e5,3) pct
                     from '{p}' group by 1 order by n desc limit 40""").df()
    print(df.to_string(index=False))
