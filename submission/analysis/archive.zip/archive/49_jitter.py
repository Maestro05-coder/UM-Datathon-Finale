import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
print("=== jitter shape: MQ->TN pc2, duration-1594 ===")
print(c.execute(f"""
select TOTAL_DURATION-1594 j, count(*) n from '{p}'
where ORDERING_BIC8='0001MQM0' and BENEFICIARY_BIC8='0009TNT0' and PARTICIPANT_COUNT=2
group by 1 order by 1""").df().T.to_string())
print("\n=== pc2 duration mod 10 / last digit uniformity ===")
print(c.execute(f"""select TOTAL_DURATION%10 d, count(*) n from '{p}' where PARTICIPANT_COUNT=2 group by 1 order by 1""").df().to_string(index=False))
print("\n=== is EPOCH sorted? (sample of first/last/middle) ===")
print(c.execute(f"""select min(EPOCH_SECONDS) mn, max(EPOCH_SECONDS) mx, count(distinct EPOCH_SECONDS) nd from '{p}'""").df().to_string(index=False))
