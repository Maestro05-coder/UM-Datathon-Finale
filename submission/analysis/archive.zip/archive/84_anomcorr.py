"""Are anomalies concentrated on specific corridors / banks?"""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, substr(BENEFICIARY_BIC8,5,2) bc,
  count(*) n, count(*) filter (where coalesce(ANOMALY_TYPE,'')<>'') a
from '{P}' group by 1,2,3""").df()
print("corridors:", len(d), " with >=1 anomaly:", (d.a > 0).sum(), f"({(d.a>0).mean():.1%})")

# concentration: share of anomalies on the top X% of corridors
dd = d[d.a > 0].sort_values('a', ascending=False)
cum = dd.a.cumsum() / dd.a.sum()
for q in (0.01, 0.05, 0.1, 0.25):
    k = max(1, int(len(dd) * q))
    print(f"top {q:.0%} of anomalous corridors carry {cum.iloc[k-1]:.1%} of all anomalies")

print("\nanomalies per corridor distribution (corridors with >=1):")
print(dd.a.value_counts().head(8).to_string())

# per-country concentration within the top-rate countries
for bc in ['PK', 'EG', 'ID', 'US']:
    s = d[(d.bc == bc) & (d.a > 0)].sort_values('a', ascending=False)
    print(f"\n{bc}: {s.a.sum()} anomalies on {len(s)} corridors; "
          f"top 5 corridors = {s.a.head(5).sum()/s.a.sum():.0%}; "
          f"max on one corridor = {s.a.max()}")

# is the anomaly rate per corridor ~ constant, or does it scale with volume?
d2 = d[d.n >= 50].copy()
d2['rate'] = d2.a / d2.n
print("\ncorridors with n>=50:", len(d2), " mean rate:", round(d2.rate.mean(), 5),
      " share with >=1 anomaly:", round((d2.a > 0).mean(), 4))
print("rate by volume bucket:")
print(d2.groupby(pd.qcut(d2.n, 6), observed=True).agg(n=('n', 'size'), rate=('rate', 'mean')).round(5).to_string())
