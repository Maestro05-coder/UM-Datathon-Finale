"""What really determines pc=2 pair latency? Compare additive-bank, country-pair, and hop-count models."""
import duckdb, numpy as np, pandas as pd
from scipy.optimize import nnls
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'

# ---- does hidden hop count change duration?
q = c.execute(f"""
with t as (select PARTICIPANT_COUNT pc, TOTAL_DURATION dur,
   (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell
 from '{P}' where PARTICIPANT_COUNT between 2 and 5)
select pc, ell, count(*) n, median(dur) med, quantile_cont(dur,0.9) p90
from t group by 1,2 having count(*)>100 order by 1,2""").df()
print("=== duration vs number of hidden hops ===")
print(q.round(1).to_string(index=False))

# ---- per-pair medians
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med,
  count(*) n from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
d['cc_o'] = d.o.str[4:6]; d['cc_b'] = d.b.str[4:6]
d['cpair'] = d.cc_o + '>' + d.cc_b

def r2(y, p):
    return 1 - ((y - p) ** 2).sum() / ((y - y.mean()) ** 2).sum()

# country-pair mean
gm = d.groupby('cpair').med.transform('mean')
print("\n=== explanatory power for pair median (all pairs) ===")
print(f"country-pair mean (levels): R2={r2(d.med, gm):.4f}  pairs={d.cpair.nunique()}")

# bank fixed effects, levels, with intercept via lstsq
banks = sorted(set(d.o) | set(d.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
A = np.zeros((len(d), 2 * nb + 1)); A[:, 0] = 1
for r, (o, b) in enumerate(zip(d.o, d.b)):
    A[r, 1 + idx[o]] += 1; A[r, 1 + nb + idx[b]] += 1
y = d.med.values.astype(float)
sol, *_ = np.linalg.lstsq(A, y, rcond=None)
print(f"bank additive, OLS levels: R2={r2(y, A @ sol):.4f}")
sol2, _ = nnls(A, y)
print(f"bank additive, NNLS levels: R2={r2(y, A @ sol2):.4f}")
print("NNLS negative count:", int((sol2 < 0).sum()))

# restrict to pairs well above the floor
mask = d.med.values > 30
print(f"\nrestricted to med>30s (n={mask.sum()}):")
print(f"  bank additive levels R2={r2(y[mask], (A @ sol)[mask]):.4f}")
print(f"  bank additive NNLS   R2={r2(y[mask], (A @ sol2)[mask]):.4f}")
print(f"  country-pair mean    R2={r2(y[mask], gm.values[mask]):.4f}")
res = (y[mask] - (A @ sol2)[mask]) / y[mask]
print("  relative residual quantiles:", pd.Series(res).quantile([.05, .25, .5, .75, .95]).round(3).to_dict())

# log-space additive
yl = np.log(y)
soll, *_ = np.linalg.lstsq(A, yl, rcond=None)
print(f"\nbank additive, OLS log: R2={r2(yl, A @ soll):.4f}")
print(f"  log residuals sd: {np.std(yl - A @ soll):.3f}")

# ---- save the best fit for the dashboard
d['pred'] = A @ sol2
d[['med', 'pred', 'n']].to_csv('dashboard/data/duration_pair_fit.csv', index=False)
print("\nwrote duration_pair_fit.csv  (NNLS additive in seconds)")
print(d.sort_values('n', ascending=False).head(6)[['o', 'b', 'med', 'pred', 'n']].round(1).to_string(index=False))
