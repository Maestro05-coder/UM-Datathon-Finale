import duckdb, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
d=c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, BIC8_PATH p, PARTICIPANT_COUNT pc,
   CURRENCY_CONVERSION_COUNT fx, string_split(BIC8_PATH,';') s from '{P}')
select count(*) n,
 sum(case when s[1]<>o then 1 else 0 end) head_mismatch,
 sum(case when s[len(s)]<>b then 1 else 0 end) tail_mismatch
from t""").df()
print(d.to_string(index=False))
print("\nshares:", (d.head_mismatch/d.n).round(5).to_string(), (d.tail_mismatch/d.n).round(5).to_string())

print("\n=== examples of head mismatch ===")
print(c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, BIC8_PATH p, PARTICIPANT_COUNT pc,
  CURRENCY_CONVERSION_COUNT fx, TRANSACTION_TYPE_CODE tt, CONTINUITY_QFLAG q
from '{P}' where string_split(BIC8_PATH,';')[1] <> ORDERING_BIC8 limit 6""").df().to_string(index=False))

print("\n=== how many rows have path ends off, by participant count ===")
print(c.execute(f"""
with t as (select PARTICIPANT_COUNT pc, string_split(BIC8_PATH,';') s, ORDERING_BIC8 o
 from '{P}')
select pc, count(*) n, sum(case when s[1]<>o then 1 else 0 end) bad,
 round(avg(case when s[1]<>o then 1 else 0 end),4) bad_share
from t group by 1 order by 1 limit 8""").df().to_string(index=False))
