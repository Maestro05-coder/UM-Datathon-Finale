import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
def cc(x): return f"substr({x},5,2)"

# country -> modal currency
mp=c.execute(f"""select {cc('ORDERING_BIC8')} c, CURRENCY_CODE cur, count(*) n,
 row_number() over (partition by {cc('ORDERING_BIC8')} order by count(*) desc) rk
 from '{P}' group by 1,2 qualify rk=1""").df()
cmap=dict(zip(mp.c,mp.cur))

d=c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, BIC8_PATH p, PARTICIPANT_COUNT pc,
 CURRENCY_CONVERSION_COUNT fx, TOTAL_DURATION dur, string_split(BIC8_PATH,';') s from '{P}'
 using sample 1500000""").df()
d['head']=[x[0] for x in d.s]
d['tail']=[x[-1] for x in d.s]
d['clean']=(d.head==d.o)&(d.tail==d.b)
d['head_samecc']=[x[4:6]==y[4:6] for x,y in zip(d['head'],d['o'])]
print("sample clean share:",round(d.clean.mean(),4))
print("noise rows where replacement head has same country as true o:",
      round(np.mean([x for x in d.loc[~d.clean,'head_samecc']]),4))

def pred_country(path):
    nodes=[s for s in path.split(';') if s!='...']
    curs=[cmap.get(n[4:6],'?') for n in nodes]
    return sum(1 for i in range(1,len(curs)) if curs[i]!=curs[i-1])

for name,sub in [('ALL',d),('CLEAN (head+tail match)',d[d.clean]),
                 ('HEAD-NOISY only',d[~d.clean])]:
    pr=[pred_country(p) for p in sub.p]
    print(f"{name:26s} n={len(sub):8d} exact match={np.mean(np.array(pr)==sub.fx.values):.4f}")

# does the noise affect the *first* conversion only?
sub=d[d.clean]
print("\nhead-noise rows: does duration follow true pair or displayed head?")
rows=[]
for r in d[~d.clean].head(4000).itertuples():
    rows.append((r.o,r.b,r.head,r.dur))
dn=pd.DataFrame(rows,columns=['o','b','head','dur'])
# base durations for true pairs and displayed pairs
base=c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=30""").df()
bb={(r.o,r.b):r.med for r in base.itertuples()}
dn['true_base']=[bb.get((r.o,r.b),np.nan) for r in dn.itertuples()]
dn['disp_base']=[bb.get((r.head,r.b),np.nan) for r in dn.itertuples()]
dn['err_true']=(dn.dur-dn.true_base).abs()
dn['err_disp']=(dn.dur-dn.disp_base).abs()
print("median |dur - true-pair base| :", round(dn.err_true.median(),1))
print("median |dur - displayed-head base| :", round(dn.err_disp.median(),1))
print("share within 30s: true=%.3f displayed=%.3f" % ((dn.err_true<30).mean(),(dn.err_disp<30).mean()))
