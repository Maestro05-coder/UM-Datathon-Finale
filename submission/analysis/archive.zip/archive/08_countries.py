import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
c.execute(f"""create or replace view v as
select *, regexp_extract(ORDERING_TOKENS,'<country_code:([A-Z]{{2}})>',1) oc,
             regexp_extract(BENEFICIARY_TOKENS,'<country_code:([A-Z]{{2}})>',1) bc,
             substr(ORDERING_BIC8,5,2) obc, substr(BENEFICIARY_BIC8,5,2) bbc
from '{p}'""")
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q("select sum(case when oc='' then 1 else 0 end) no_oc, sum(case when bc='' then 1 else 0 end) no_bc, count(*) from v",'missing country tokens')
q("select sum(case when oc=obc then 1 else 0 end) match, sum(case when oc<>obc then 1 else 0 end) mismatch, count(*) from v",'ordering party vs bank country')
q("select sum(case when bc=bbc then 1 else 0 end) match, sum(case when bc<>bbc then 1 else 0 end) mismatch, count(*) from v",'benef party vs bank country')
q("select sum(case when oc=bc then 1 else 0 end) same, sum(case when oc<>bc then 1 else 0 end) diff, count(*) from v",'party countries same')
q("""select * from (select oc, count(*) n from v group by 1 order by n desc limit 15)""",'top party countries')
q("""select * from (select bc, count(*) n from v group by 1 order by n desc limit 15)""",'top benef party countries')
