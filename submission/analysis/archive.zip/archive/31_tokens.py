import polars as pl, re, collections
df=pl.read_parquet('analysis/payments.parquet', n_rows=5000)
tok_re=re.compile(r'<([a-z_]+)(?::([^>]*))?>')
# print raw strings with escapes for 25 rows covering types
for r in df.iter_rows(named=True):
    if r['ANOMALY_TYPE']: continue
    print('----',r['ORDERING_TYPE'],r['BENEFICIARY_TYPE'])
    print('OD',repr(r['ORDERING_DETAILS']))
    print('OT',r['ORDERING_TOKENS'])
    if r['ORDERING_DETAILS'] and len(r['ORDERING_DETAILS'])<200:
        toks=tok_re.findall(r['ORDERING_TOKENS'])
        print('toks',toks[:20],'sumlen',sum(int(b.split(':')[-1]) for a,b in toks if b and b.split(':')[-1].isdigit()),'len',len(r['ORDERING_DETAILS']))
    break
# aggregate token vocabulary on 200k
df=pl.read_parquet('analysis/payments.parquet', n_rows=200000)
cnt=collections.Counter()
pt=collections.Counter()
for col in ['ORDERING_TOKENS','BENEFICIARY_TOKENS']:
    for s in df[col]:
        for m in tok_re.finditer(s or ''):
            cnt[m.group(1)]+=1
            pt[(m.group(1),m.group(2))]+=1
print('TOKEN TYPES:',cnt.most_common())
print('TOP PARAMS:')
for k,v in pt.most_common(80): print(k,v)
