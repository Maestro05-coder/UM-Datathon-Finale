import duckdb, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
q=f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, count(*) n,
       sum(CURRENCY_CONVERSION_COUNT) s,
       count(distinct CURRENCY_CONVERSION_COUNT) k,
       count(distinct BIC8_PATH) npaths
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100"""
d=c.execute(q).df()
d['p1']=d.s/d.n
mixed=d[(d.p1>0.15)&(d.p1<0.85)].sort_values('n',ascending=False)
print("mixed cells (15-85% conv=1):",len(mixed),"of",len(d), " rows in mixed:",mixed.n.sum())
print(mixed.head(15).to_string(index=False))

print("\n=== inspect top mixed cell in detail ===")
row=mixed.iloc[0]
print("cell:",row.o,"->",row.b,"p1=",round(row.p1,3))
print(c.execute(f"""
select BIC8_PATH path, CURRENCY_CODE pay, CURRENCY_CONVERSION_COUNT fx, count(*) n
from '{P}' where ORDERING_BIC8='{row.o}' and BENEFICIARY_BIC8='{row.b}' and PARTICIPANT_COUNT=2
group by 1,2,3 order by n desc limit 12""").df().to_string(index=False))

print("\n=== is conv explained by path shape for that cell? ===")
print(c.execute(f"""
select BIC8_PATH, avg(CURRENCY_CONVERSION_COUNT) p, count(*) n
from '{P}' where ORDERING_BIC8='{row.o}' and BENEFICIARY_BIC8='{row.b}' and PARTICIPANT_COUNT=2
group by 1 order by n desc""").df().to_string(index=False))
