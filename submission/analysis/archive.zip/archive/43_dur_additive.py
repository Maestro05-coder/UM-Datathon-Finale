import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

d=c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
print("pairs:",len(d), "rows covered:", d.n.sum())

banks=sorted(set(d.o)|set(d.b)); idx={b:i for i,b in enumerate(banks)}
A=np.zeros((len(d),len(banks))); 
for r,(o,b) in enumerate(zip(d.o,d.b)):
    A[r,idx[o]]+=1; A[r,idx[b]]+=1
y=d.med.values.astype(float)
# least squares with non-negativity via lstsq then clip
sol,res,rank,sv=np.linalg.lstsq(A,y,rcond=None)
pred=A@sol
r2=1-((y-pred)**2).sum()/((y-y.mean())**2).sum()
print(f"additive bank model R2={r2:.4f}  residual sd={np.std(y-pred):.1f}  y mean={y.mean():.1f} sd={y.std():.1f}")

# symmetry check
s=d.merge(d,left_on=['o','b'],right_on=['b','o'],suffixes=('','_r'))
print("\nsymmetry corr base(o,b) vs base(b,o):", round(np.corrcoef(s.med,s.med_r)[0,1],3),
      " median abs diff:", round(np.median(np.abs(s.med-s.med_r)),1), " n:",len(s))

# does base correlate with BIC numeric code?
d['oc']=d.o.str[:4].astype(int); d['bc']=d.b.str[:4].astype(int)
for f in ['oc','bc']:
    print(f"corr med vs {f}: {np.corrcoef(d.med,d[f])[0,1]:.3f}")
print("corr med vs |oc-bc|:", round(np.corrcoef(d.med,(d.oc-d.bc).abs())[0,1],3))
print("corr med vs oc+bc:", round(np.corrcoef(d.med,d.oc+d.bc)[0,1],3))

# top/bottom bases
print("\nbase distribution quantiles:", np.round(np.quantile(y,[0,.1,.25,.5,.75,.9,.99,1]),1))
print("\nrandom sample of pairs:")
print(d.sample(15,random_state=1)[['o','b','med','n']].to_string(index=False))
