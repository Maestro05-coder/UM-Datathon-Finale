import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
off={'US':-5,'CH':1,'GB':0,'DE':1,'FR':1,'IT':1,'SG':8,'CN':8,'JP':9,'AU':10,'IN':5.5,'BR':-3,'ZA':2,'AE':4,'RU':3,'UA':2,'TR':3,'CA':-5,'HK':8,'KR':9,'MY':8,'MX':-6,'ID':7,'TH':7,'VN':7,'BD':6,'KE':3,'ET':3,'NG':1,'EG':2,'SA':3,'QA':3,'IL':2,'PL':1,'CZ':1,'SE':1,'DK':1,'NO':1,'FI':2,'IE':0,'PT':0,'ES':1,'NL':1,'BE':1,'AT':1,'LU':1,'GR':2,'NZ':12}
rows=[]
for ct,o in off.items():
    df=c.execute(f"""select (hour(to_timestamp(EPOCH_SECONDS)) + {o}) % 24 h, total_duration d from '{p}'
      where PARTICIPANT_COUNT=2 and substr(BENEFICIARY_BIC8,5,2)='{ct}' using sample 30000""").df()
    if len(df)<1000: continue
    df['h']=df.h.astype(int)
    g=df.groupby('h').d.agg(['count','median','mean'])
    rows.append((ct,o,g['median'].values))
print(pd.DataFrame(rows,columns=['ctry','off','med_by_local_hour']).to_string(index=False))
# aggregate all countries using offsets
c.execute("create or replace temp table offs(ctry varchar, off double)")
vals=','.join([f"('{k}',{v})" for k,v in off.items()])
c.execute(f"insert into offs values {vals}")
q=f"""select ((hour(to_timestamp(EPOCH_SECONDS)) + o.off)::int % 24) lh, count(*) n,
round(median(TOTAL_DURATION),0) med, round(avg(TOTAL_DURATION),0) mean
from '{p}' join offs o on substr(BENEFICIARY_BIC8,5,2)=o.ctry
where PARTICIPANT_COUNT=2 group by 1 order by 1"""
print(c.execute(q).df().to_string(index=False))
q2=q.replace("BENEFICIARY_BIC8","ORDERING_BIC8")
print(c.execute(q2).df().to_string(index=False))
