"""Diagnose the latency structure: are bank effects discrete? Is the model max(floor, a_o+a_b)?"""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med,
  quantile_cont(TOTAL_DURATION,0.1) p10, quantile_cont(TOTAL_DURATION,0.9) p90, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()

print("=== distribution of pair medians ===")
print(d.med.describe(percentiles=[.01,.05,.1,.25,.5,.75,.9,.99]).round(1).to_string())
print("share med<=10s:", round((d.med<=10).mean(),4), " med<=20s:", round((d.med<=20).mean(),4))
print("\nmost common medians:")
print(d.med.value_counts().head(12).to_string())

print("\n=== within-pair spread: p90-p10 ===")
d['spread'] = d.p90 - d.p10
print(d.spread.describe(percentiles=[.05,.5,.95]).round(1).to_string())

# bank effects via OLS with intercept
banks = sorted(set(d.o) | set(d.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
A = np.zeros((len(d), 2 * nb + 1)); A[:, 0] = 1
for r, (o, b) in enumerate(zip(d.o, d.b)):
    A[r, 1 + idx[o]] += 1; A[r, 1 + nb + idx[b]] += 1
y = d.med.values.astype(float)
sol, *_ = np.linalg.lstsq(A, y, rcond=None)
eff = sol[1:]
print("\n=== bank latency effects (OLS, seconds) ===")
print(pd.Series(eff).describe(percentiles=[.05,.25,.5,.75,.9,.95,.99]).round(1).to_string())
print("quantiles of effect:", pd.Series(eff).quantile([.1,.25,.5,.75,.9,.95,.99]).round(1).to_dict())

# how well does max(9, pred) do?
pred = np.maximum(9, A @ sol)
print("\nR2 levels:", round(1-((y-pred)**2).sum()/((y-y.mean())**2).sum(),4))
rel = np.abs(pred-y)/y
print("median rel err:", round(np.median(rel),4), " share<10%:", round((rel<0.1).mean(),3),
      " share<25%:", round((rel<0.25).mean(),3))

# per-bank: fit a single effect from med - partner effect and inspect consistency
# choose banks with >=5 partners
part = pd.concat([d[['o','b','med']].rename(columns={'o':'bank','b':'other'}),
                  d[['b','o','med']].rename(columns={'b':'bank','o':'other'})])
cnt = part.groupby('bank').size()
big = cnt[cnt>=8].index
print("\nbanks with >=8 partners:", len(big))

# is the additive residual symmetric noise or structure? check residual vs med
res = y - pred
bins = pd.qcut(d.med, 8, duplicates='drop')
print("\nmean residual by median bucket:")
print(pd.DataFrame({'med':d.med,'res':res}).groupby(bins, observed=True).agg(
    n=('res','size'), med=('med','mean'), res_mean=('res','mean'), res_sd=('res','std')).round(1).to_string())

# test exact log-additivity for the top 40 banks by volume
top = d.groupby('o').n.sum().sort_values(ascending=False).head(40).index
sub = d[d.o.isin(top) & d.b.isin(top)]
print("\ntop40x40 submatrix pairs:", len(sub))
