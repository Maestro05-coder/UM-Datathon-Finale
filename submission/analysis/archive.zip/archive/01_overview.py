import duckdb, time
con = duckdb.connect()
con.execute("SET threads=8")
con.execute("SET memory_limit='8GB'")
t0=time.time()
q = """
SELECT count(*) n,
       min(EPOCH_SECONDS) mn, max(EPOCH_SECONDS) mx,
       count(distinct CURRENCY_CODE) ncur,
       count(distinct ORDERING_BIC8) nobic,
       count(distinct BENEFICIARY_BIC8) nbic,
       avg(USD_AMOUNT) avgamt, median(USD_AMOUNT) medamt,
       min(USD_AMOUNT) minamt, max(USD_AMOUNT) maxamt,
       avg(TOTAL_DURATION) avgdur, max(TOTAL_DURATION) maxdur,
       count(distinct ANOMALY_TYPE) nanom
FROM read_csv('swift_umdac_datathon_2026_fictitious_payment_data.csv', header=true, quote='"', escape='"')
"""
print(con.execute(q).fetchall())
print('secs', time.time()-t0)
