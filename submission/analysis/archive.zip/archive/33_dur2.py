import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select PARTICIPANT_COUNT pc, count(*) n,
round(quantile_cont(TOTAL_DURATION,0.1),0) p10, round(quantile_cont(TOTAL_DURATION,0.25),0) p25,
round(quantile_cont(TOTAL_DURATION,0.5),0) p50, round(quantile_cont(TOTAL_DURATION,0.75),0) p75,
round(quantile_cont(TOTAL_DURATION,0.9),0) p90, round(quantile_cont(TOTAL_DURATION,0.99),0) p99,
round(avg(TOTAL_DURATION),0) mean from '{p}' where pc<=8 group by 1 order by 1""",'dur quantiles by pc')
q(f"""select CURRENCY_CONVERSION_COUNT cc, count(*) n,
round(quantile_cont(TOTAL_DURATION,0.25),0) p25, round(quantile_cont(TOTAL_DURATION,0.5),0) p50,
round(quantile_cont(TOTAL_DURATION,0.9),0) p90, round(avg(TOTAL_DURATION),0) mean
from '{p}' where PARTICIPANT_COUNT=3 group by 1 order by 1""",'pc3 by cc')
q(f"""select substr(BENEFICIARY_BIC8,5,2) bc, count(*) n, round(median(TOTAL_DURATION),0) med
from '{p}' where PARTICIPANT_COUNT=2 group by 1 order by n desc limit 25""",'pc2 med by benef ctry')
q(f"""select BENEFICIARY_BIC8, count(*) n, round(median(TOTAL_DURATION),0) med from '{p}'
where PARTICIPANT_COUNT=2 group by 1 order by n desc limit 25""",'pc2 med by benef bank')
q(f"""select ORDERING_BIC8, count(*) n, round(median(TOTAL_DURATION),0) med from '{p}'
where PARTICIPANT_COUNT=2 group by 1 order by n desc limit 25""",'pc2 med by order bank')
q(f"""select substr(ORDERING_BIC8,5,2) oc, substr(BENEFICIARY_BIC8,5,2) bc, count(*) n, round(median(TOTAL_DURATION),0) med
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>5000 order by med desc limit 25""",'pc2 slowest country pairs')
q(f"""select substr(ORDERING_BIC8,5,2) oc, substr(BENEFICIARY_BIC8,5,2) bc, count(*) n, round(median(TOTAL_DURATION),0) med
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>5000 order by med limit 25""",'pc2 fastest country pairs')
