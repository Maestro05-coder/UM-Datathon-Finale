import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
c.execute(f"""create or replace temp table ap as select EPOCH_SECONDS ts, USD_AMOUNT amt, CURRENCY_CODE cur,
 ORDERING_ACCOUNT oa, BENEFICIARY_ACCOUNT ba, ORDERING_DETAILS od, BENEFICIARY_DETAILS bd,
 BIC8_PATH path, ANOMALY_TYPE an, ORDERING_TYPE ot, BENEFICIARY_TYPE bt from '{p}'""")
for typ in ['DUPLICATE_PAYMENT','ACCOUNT_REPLACEMENT_SCAM','CUSTOMER_RECALL','CEO_SCAM','ROMANCE_SCAM','FAT_FINGER_MISTAKE']:
    print('#####',typ)
    q=f"""
    select count(*) pairs, count(distinct a.oa) oa,
      round(avg(abs(a.ts-b.ts))/60.0,1) avg_mins, round(median(abs(a.ts-b.ts))/60.0,1) med_mins,
      sum(case when a.ba=b.ba and abs(a.amt-b.amt)<0.01 then 1 else 0 end) same_ba_amt,
      sum(case when a.ba<>b.ba and abs(a.amt-b.amt)<0.01 then 1 else 0 end) diff_ba_same_amt,
      sum(case when a.ba=b.ba then 1 else 0 end) same_ba
    from ap a join ap b on a.oa=b.oa and a.ts<>b.ts
    where a.an='{typ}'
    """
    print(c.execute(q).df().to_string(index=False))
    q2=f"""
    select case when a.ba=b.ba then 'sameBA' else 'diffBA' end k2,
      case when abs(a.amt-b.amt)<0.01 then 'sameAmt' when abs(a.amt-b.amt)/a.amt<0.05 then 'amt5pct' else 'diffAmt' end k3,
      count(*) n, round(median(abs(a.ts-b.ts))/60,1) med_min
    from ap a join ap b on a.oa=b.oa and a.ts<>b.ts
    where a.an='{typ}' group by 1,2 order by n desc limit 12"""
    print(c.execute(q2).df().to_string(index=False))
