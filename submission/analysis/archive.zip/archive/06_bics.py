import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select length(ORDERING_BIC8) l, count(*) from '{p}' group by 1 order by 1""",'bic len')
q(f"""select substr(ORDERING_BIC8,5,2) c, count(*) n, round(100.0*count(*)/1e5,2) pct, count(distinct ORDERING_BIC8) nbank
from '{p}' group by 1 order by n desc limit 50""",'ordering bic country')
q(f"""select substr(BENEFICIARY_BIC8,5,2) c, count(*) n, round(100.0*count(*)/1e5,2) pct, count(distinct BENEFICIARY_BIC8) nbank
from '{p}' group by 1 order by n desc limit 50""",'beneficiary bic country')
q(f"""select ORDERING_BIC8, count(*) n from '{p}' group by 1 order by n desc limit 20""",'top ordering bic')
q(f"""select BENEFICIARY_BIC8, count(*) n from '{p}' group by 1 order by n desc limit 20""",'top benef bic')
q(f"""select ORDERING_BIC8 from '{p}' where substr(ORDERING_BIC8,5,2)='MY' limit 20""",'MY bics')
q(f"""select ORDERING_BIC8 from '{p}' where substr(ORDERING_BIC8,5,2)='US' limit 20""",'US bics')
q(f"""select ORDERING_BIC8 from '{p}' where substr(ORDERING_BIC8,5,2)='GB' limit 20""",'GB bics')
q(f"""select count(distinct ORDERING_BIC8) from '{p}' where substr(ORDERING_BIC8,5,2)='US'""",'US unique')
