import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select substr(ORDERING_BIC8,5,2) ctry, CURRENCY_CODE cur, count(*) n,
round(100.0*count(*)/sum(count(*)) over (partition by substr(ORDERING_BIC8,5,2)),2) pct
from '{p}' group by 1,2 qualify row_number() over (partition by ctry order by n desc)<=3
order by ctry limit 200""",'cur by ordering country')
q(f"""select CURRENCY_CODE cur, count(distinct substr(ORDERING_BIC8,5,2)) nc, count(*) n from '{p}' group by 1 order by n desc limit 40""",'cur distinct countries')
