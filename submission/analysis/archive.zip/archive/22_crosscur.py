import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
def top(ctry,cur,lo,hi,k=12):
    df=c.execute(f"""select USD_AMOUNT a,count(*) n from '{p}' where substr(ORDERING_BIC8,5,2)='{ctry}'
    and CURRENCY_CODE='{cur}' and USD_AMOUNT between {lo} and {hi} group by 1 order by n desc limit {k}""").df()
    print('###',ctry,cur,df.to_string(index=False).replace('\n',' | '))
top('CH','CHF',900,1400)
top('CH','EUR',900,1400)
top('CH','USD',900,1400)
top('US','USD',900,1400)
top('US','EUR',900,1400)
top('DE','EUR',900,1400)
top('DE','USD',900,1400)
top('CN','CNY',900,2000)
top('CN','EUR',900,2000)
top('IN','INR',50,150)
top('IN','USD',50,150)
