import duckdb, glob, os
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
h = c.execute("""
select ORDERING_TYPE || BENEFICIARY_TYPE AS pair_code,
       floor(log10(USD_AMOUNT)*10)/10 AS b, count(*) n
from 'analysis/payments.parquet' where USD_AMOUNT > 0 group by 1,2""").df()
h.to_csv('dashboard/data/amount_hist.csv', index=False)
print(h.groupby('pair_code').n.sum().to_string())

print("\n=== scanning dashboard/data for mojibake ===")
bad = []
for f in glob.glob('dashboard/data/*'):
    raw = open(f, 'rb').read()
    if b'\xc3\xa2\xe2\x80\xa0' in raw or b'\xc3\xa2\xe2\x82\xac' in raw:
        bad.append(f)
print("files with double-encoded UTF-8:", bad or "none")
